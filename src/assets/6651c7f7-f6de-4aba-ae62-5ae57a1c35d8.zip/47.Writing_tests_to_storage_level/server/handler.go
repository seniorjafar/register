package server

import (
	"encoding/json"
	"fmt"
	"github.com/google/uuid"
	"net/http"
	"token/model"
)

func LoginHandler(w http.ResponseWriter, req *http.Request) {
	user := req.Context().Value("user").(model.User)
	w.Header().Set("Content-Type", "application/json")
	tokenString, err := GenerateToken(user)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		errorMessage := model.Error{Message: "Internal Server Error"}
		jsonResponse, _ := json.Marshal(errorMessage)
		w.Write(jsonResponse)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(jsonResponse)
		return
	}
	tokenModel := model.Token{Token: tokenString}
	jsonResponse, _ := json.Marshal(tokenModel)
	w.WriteHeader(http.StatusOK)
	w.Write(jsonResponse)

	model.Users = append(model.Users, user)
	fmt.Println(model.Users)
}

func ProtectedHandler(w http.ResponseWriter, req *http.Request) {
	id := req.Context().Value("id").(uuid.UUID)
	for _, user := range model.Users {
		if user.ID == id {
			if user.Role != "admin" {
				w.Header().Set("Content-Type", "application/json")
				errorMessage := model.Error{Message: "Forbidden"}
				jsonResponse, _ := json.Marshal(errorMessage)
				w.Write(jsonResponse)
				w.WriteHeader(http.StatusForbidden)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(fmt.Sprintf(`{"Message":"Hello world %s"}`, user.Username)))
			return
		}
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusNotFound)
	w.Write([]byte(`{"Message":"Not Found"}`))
}
