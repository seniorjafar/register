package server

import (
	"fmt"
	"github.com/golang-jwt/jwt/v5"
)

func VerifyToken(tokenString string) (bool, jwt.Token) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return Secret, nil
	})
	fmt.Println(err)
	if err != nil {

		return false, *token
	}
	if !token.Valid {

		return false, *token
	}
	return true, *token
}
