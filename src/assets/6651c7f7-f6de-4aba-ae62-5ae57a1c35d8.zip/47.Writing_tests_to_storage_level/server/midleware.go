package server

import (
	"context"
	"encoding/json"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"net/http"
	"strings"
	"time"
	"token/model"
)

func LoginMiddleWare(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user := model.User{}
		err := json.NewDecoder(r.Body).Decode(&user)
		if err != nil {
			errorMessage := model.Error{Message: "Invalid request body"}

			jsonResponse, _ := json.Marshal(errorMessage)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			w.Write(jsonResponse)
			return
		}
		if user.Username == "" || user.Email == "" || user.Exp != 0 || user.Iat != 0 || user.Role == "" {
			errorMessage := model.Error{Message: "Invalid username or email"}
			jsonResponse, _ := json.Marshal(errorMessage)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			w.Write(jsonResponse)
			return
		}

		currentTime := time.Now()

		// Устанавливаем поле "exp" (expiration time) на один час вперед от текущего времени
		user.Exp = currentTime.Add(time.Hour).Unix()

		// Устанавливаем поле "iat" (issued at time) на текущее время
		user.Iat = currentTime.Unix()
		user.ID = uuid.New()
		ctx := context.WithValue(r.Context(), "user", user)
		next.ServeHTTP(w, r.WithContext(ctx))
	}
}

func CheckMiddleWare(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token := r.Header.Get("Authorization")
		if token == "" {
			errorMessage := model.Error{Message: "Invalid token"}
			jsonResponse, _ := json.Marshal(errorMessage)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			w.Write(jsonResponse)
			return
		}
		tokenString := strings.Split(token, " ")
		ok, tokenParce := VerifyToken(tokenString[1])
		if ok == false {
			errorMessage := model.Error{Message: "Invalid token"}
			jsonResponse, _ := json.Marshal(errorMessage)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			w.Write(jsonResponse)
			return
		}

		var id uuid.UUID
		if claims, ok := tokenParce.Claims.(jwt.MapClaims); ok {
			idStr, ok := claims["id"].(string)
			if !ok {
				w.WriteHeader(http.StatusBadRequest)
			}
			var err error
			id, err = uuid.Parse(idStr)
			if err != nil {
				w.WriteHeader(http.StatusBadRequest)
				w.Write([]byte(err.Error()))
			}
		}

		ctx := context.WithValue(r.Context(), "id", id)
		next.ServeHTTP(w, r.WithContext(ctx))
	}

}
