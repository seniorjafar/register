package server

import (
	"github.com/golang-jwt/jwt/v5"
	"token/model"
)

var Secret = []byte("secret")

func GenerateToken(user model.User) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"username": user.Username,
		"id":       user.ID,
		"role":     user.Role,
		"exp":      user.Exp,
		"lat":      user.Iat,
	})
	tokenString, err := token.SignedString(Secret)
	if err != nil {
		return "", err
	}
	return tokenString, nil
}
