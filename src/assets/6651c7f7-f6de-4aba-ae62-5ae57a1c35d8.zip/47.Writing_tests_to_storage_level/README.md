## Uy vazifa

### Bugungi jwt-token misolini kengariting:
- jwt token `payload`iga `role` digan kalit qo'shing
- `/protected` endpointida `role` admin bo'masa `Forbidden` qaytaring
- `Authorization` headerni tekshirishini middleware or'qali qiling


