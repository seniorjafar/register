package main

import (
	"fmt"
	"log"
	"net/http"
	"time"
	"token/server"
)

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /login", server.LoginMiddleWare(server.LoginHandler))
	mux.HandleFunc("GET /protected", server.CheckMiddleWare(server.ProtectedHandler))
	server1 := http.Server{
		Addr:         ":8080",
		Handler:      mux,
		IdleTimeout:  120 * time.Second,
		ReadTimeout:  12 * time.Second,
		WriteTimeout: 12 * time.Second,
	}
	fmt.Println("server listening on port 8080")
	log.Fatal(server1.ListenAndServe())
}
