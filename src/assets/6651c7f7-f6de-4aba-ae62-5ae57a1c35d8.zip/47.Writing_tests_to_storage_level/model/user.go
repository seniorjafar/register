package model

import (
	"github.com/google/uuid"
)

type User struct {
	ID       uuid.UUID `json:"id"`
	Username string    `json:"username"`
	Email    string    `json:"email"`
	Exp      int64     `json:"exp"`
	Iat      int64     `json:"iat"`
	Role     string    `json:"role"`
}

var Users = []User{}
